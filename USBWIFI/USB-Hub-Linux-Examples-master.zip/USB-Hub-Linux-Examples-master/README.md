# USB-Hub-Linux-Examples
Linux example code that accompanies MCHP USB Smart hubs

# General USB Examples
Within this folder a user can find example code that allows compliance tests to be run.

# USB Hub Feature Example
Within this folder, example code can be be found that is compatible with various Microchip Hubs. Examples include USB bridging, battery charging and role switching.
