const char * n2n_sw_version   = "2.0.0";
const char * n2n_sw_osName    = "Win32";
const char * n2n_sw_buildDate = __DATE__ " " __TIME__;
